#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define MAX_LINE_LENGTH 200

//Lara Gul Kucukdevlet

int count_word_occurrences_in_sequence(char *word, char *sequence);
void calculate_tf_idf_scores(char *word);
void calculate_idf_score(char **word);

float tf_scores[6]; //keeps healthy_count ,total_healthy_count,tf score, tf scores for healthy and cancerous ,cancerous_count and total_cancerous_count;
float idf_scores[6];   //keeps same variables with tf_scores .
float tf_idf_scores[2];  //keeps tf-idf scores for both healthy and cancerous words.

int main(int argc, char **argv){

    if (strcmp(argv[1], "calculate-tf") == 0) // analyze frequencies
    {
        calculate_tf_idf_scores(argv[2]);
        printf("Total Healthy: %.0f\n", tf_scores[0]);    //print statements
        printf("Word in Healthy: %.0f\n", tf_scores[1]);
        printf("Calculated tf value for this word: %.6f\n", tf_scores[2]);
        printf("Total Cancerous: %.0f\n", tf_scores[3]);
        printf("Word in Cancerous: %.0f\n", tf_scores[4]);
        printf("Calculated tf value for this word: %.6f\n", tf_scores[5]);
        if (tf_scores[1] > tf_scores[4]){   //if healthy_count > cancerous_count
            printf("This word is mostly used for healthy sequences.");
	}
	else if(tf_scores[1]<tf_scores[4]) { // if healthy_count < cancerous_count

            printf("This word is mostly used for cancerous sequences.");
	}
    	else{
	    printf("This word is not occur in the text.");  //if the word is not in the sequnce 

	}	

    }

    else if (strcmp(argv[1], "predict") == 0) // cancerous sequence detection
    {
        calculate_idf_score(argv);

        printf("Total tf-idf score from healthy messages for the sequence: %.6f\n", tf_idf_scores[0]); //prints tf-idf score from healthy messages
        printf("Total tf-idf score from cancerous sequence for the sequence: %.6f\n", tf_idf_scores[1]); //prints tf-idf score from cancerous sequence 
        if (tf_idf_scores[0] > tf_idf_scores[1]){  //compare the tf-idf scores of sequences.

            printf("This sequence is not cancerous.");
	}
   // 	else if(tf_idf_scores[0]==0 && tf_idf_scores[1]==0){
//		printf("Tf idf scores are found to be 0, cancerous sequnece detection failed.");
//	}	
        else{
            printf("This sequence is cancerous.");
	}    
    }
    else
    {
        printf("Wrong Function!\n");
    }

    return 0;
}

int count_word_occurrences_in_sequence(char *word, char *sequence) //count the number of occurences of words in sequence
{
    int count = 0; //initialize count variable with 0
    char *position = sequence;  // assign position pointer to sequence

    while ((position = strstr(position, word)) != NULL) //while word pattern matches with position increment count and poisiton 
    {
        count++;
        position += strlen(word);
    }

    return count;
}

void calculate_tf_idf_scores(char *word){
    char line[MAX_LINE_LENGTH];
    char *token; //in order to read file line by line
    int total_healthy_count = 0;  //initialize total healthy and cancerous counts.
    int total_cancerous_count = 0;
    int healthy_count = 0;
    int cancerous_count = 0;
    float count[6];

    // Open sequences.txt file
    FILE *fp = fopen("sequences.txt", "r");
    if (fp == NULL)
    {
        printf("Error: Could not open sequences.txt file.\n");
        // return;
    }
    // Read sequences.txt file line by line
    while (fgets(line, MAX_LINE_LENGTH, fp) != NULL)
    {
        // Get label and sequence from line
        token = strtok(line, "\t");
        int label = atoi(token);
        token = strtok(NULL, "\n");
        char *sequence = token;
        if (label == 0)
        {
            healthy_count = healthy_count + count_word_occurrences_in_sequence(word, sequence);
            total_healthy_count++;     //if the label is 0 then increase the amount of healthy_count with healthy_count and count from count_word_occurences_in_sequence function.
	    				//increase the total_healthy_count
        }
        else
        {
            cancerous_count = cancerous_count + count_word_occurrences_in_sequence(word, sequence);
            total_cancerous_count++;    //if label is 1 increase the cancerous_count and total_cancerous_count
        }
    }
    // Close sequences.txt file
    fclose(fp);

    tf_scores[0] = (float)total_healthy_count;
    tf_scores[1] = (float)healthy_count;
    tf_scores[2] = (float)healthy_count / (float)total_healthy_count;  //calculates tf for healthy words
    tf_scores[3] = (float)total_cancerous_count;
    tf_scores[4] = (float)cancerous_count;
    tf_scores[5] = (float)cancerous_count / (float)total_cancerous_count; //calculates tf for canceorus words

    idf_scores[0] = (float)total_healthy_count;  //assign idf_scores[0] to total_healthy_count abd idf_scores[1] to healthy_count to calculate idf score
    idf_scores[1] = (float)healthy_count;
    if ((float)healthy_count != 0){  //calculates idf score for healthy words
        idf_scores[2] = logf((float)total_healthy_count / (float)healthy_count);
    }	
    else{
        idf_scores[2] = 0;
    	idf_scores[3] = (float)total_cancerous_count;
    	idf_scores[4] = (float)cancerous_count;
    	if ((float)cancerous_count != 0){ //calculates cancerous words' idf score.
        	idf_scores[5] = logf((float)total_cancerous_count / (float)cancerous_count);
	}	
    	else{
        	idf_scores[5] = 0;
	}
    // return count;
    }
}
void calculate_idf_score(char **word){
	int i;
	for ( i = 2; i < 10; i++){
        // calculate_idf_score(argv[i]);
        calculate_tf_idf_scores(word[i]);
        tf_idf_scores[0] += tf_scores[2] * idf_scores[2]; //caqlculates tf-idf score for healthy words.
        tf_idf_scores[1] += tf_scores[5] * idf_scores[5]; // calculates tf-idf score for cancerous words
    
	}

}
