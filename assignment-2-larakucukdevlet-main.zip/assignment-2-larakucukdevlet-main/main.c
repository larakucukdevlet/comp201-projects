
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <ctype.h>

#define MAX_WORD_LEN 100

char* get_random_word(char* file_name);
void display_word_status(char* word, char guessed_letters[]);
int is_word_guessed(char* word, char guessed_letters[], int guessed_count);
int is_guess_valid(char* word, char guessed_letters[], char guess);
int guess_word(char* word);
void play_game(char* file_name);
char get_guess();

int main() {
    
    char* file_name = "words.txt";
    play_game(file_name);
    return 0;
}
char* get_random_word(char* file_name){    //kelimeyi alıyor
// Function to get a random word from a file
	FILE* fp;
	char line[100];
	char * word= NULL;//malloc(MAX_WORD_LEN * sizeof(char));
	int count=0;

	//Open file for reading
	fp=fopen(file_name,"r");  //reading lines from file
	if(fp==NULL){
		printf("Could not open file%s\n",file_name);
		return NULL;
	}
	else{
		while(fgets(line,100,fp)!=NULL){
		srand(time(NULL));// eveytime it executes, it reads abother random word different from previous.
					//reading and storing the words at every  line by line variable.
			if(rand()%++count==0){  //genereates random number between 0 to count.
				word=malloc(strlen(line)+1);//added one to lenght of the word to  ensure there	is null terminator character.
				if(word!=NULL){
					strcpy(word,line); //copy the word in the line to word variable.
					printf("%c\n",word);
				}
			}
		}
	}
	fclose(fp);
	//printf("%c\n",word);
	return word;	

}

// Function to get a valid guess from the user
char get_guess() { //KESİN ÇALIŞIUOR
	char guess;

	printf("Please enter your guess:");//taking input from user
	scanf("%c",&guess); //passed with guess's address to modify the original variable guess. not copy of it.
	while(getchar()!='\n'){
        	return toupper(guess);
	      	// make the guess characters upper.
	} 
 
}

// Function to display the status of the word with blanks for unguessed letters
void display_word_status(char* word, char guessed_letters[]) {  //Çalışıyor olmalı
	int len=strlen(word);
	char display_array[len];
	for(int i=0;i<strlen(display_array);i++){
		display_array[i]='-';
	}	
	display_array[len]='\0';  //with display_array user can see the guessed letters and their positions.
	char guess=get_guess(); //calling get_guess() method
	for(int i=0;i<strlen(word);i++){
		//guessed_letters[i]=guess;
		for(int y=0;y<strlen(guessed_letters);y++){//if guessed_letters any character equals to word's any character it will assign it to display_array
			if(toupper(guessed_letters[y])==toupper(word[i])){
				display_array[i]=word[i];
			//	break;
			}
			/*else{
				display_array[i]='-'; //if characters are not same it will show -
				break;
			}*/
		}
		
		printf("Word:%s\n",display_array);	
		break;
	}






}
// Function to determine if the word has been fully guessed


int is_word_guessed(char* word, char guessed_letters[], int guessed_count) {//kesin çalışmalı
	display_word_status(word,guessed_letters);
	int word_length=strlen(word);
	guessed_count=0;

		

	for(int i=0;i<word_length;i++){
		for(int y=0;y<strlen(guessed_letters);y++){
			if(word[i]==guessed_letters[y]){
				guessed_count++;
				if(guessed_count==word_length){//if guessed_letter count equals to word's length then it is guessed completely.
					//printf("1");
					return 1;
				}
				
				else{
					//break;
					//printf("0");
					return 0;
				}
				break;

			}	

		}
	}


}	
	

// Function to determine if a guess is valid (not already guessed and in the word)
int is_guess_valid(char* word, char guessed_letters[], char guess) {   //KESİN ÇALIŞIYOR

	while(isalpha(guess)){  //evaluated whether the guess is a letter.
		printf("Invalid guess. Please enter a letter.\n");
		//return 0;
		if(strchr(word,guess)!=NULL){ 
	      		printf("valid guess\n");
			//if guess character is found in word return 1
			return 1;  
		}
		else if(strchr(word,guess)==NULL){
			printf("The word does not contain %c\n",guess);
			return -1; //if guess character is not found in word return 0.
		}
	}	
}	
	

// A single round of the game.
int guess_word(char* word) { 
	char guess=get_guess(word);
	int max_guesses=strlen(word);
	int wrong_guesses=0;
	int guessed_count=0;
	char guessed_letters[max_guesses+1];  //created an array to store the guessed characters
	guessed_letters[max_guesses+1]='\0';
	//char guess=get_guess(word);
	guessed_letters[guessed_count]=guess;
	printf("Welcome to the word guessing game!\n The word has %d letters.\n",strlen(word));
	printf("You have %d guesses left\n",max_guesses-wrong_guesses);	
	while(wrong_guesses<max_guesses){
		//char guess =get_guess(word);  
		//guessed_letters[guessed_count]=guess;
		display_word_status(word,guessed_letters);
		//guessed_letters[guessed_count]=guess;
		if(is_guess_valid(word,guessed_letters,guess)==1){ //if word contains guess character increase guessed_count
			guessed_count++;
			guessed_letters[guessed_count]=guess;
			display_word_status(word,guessed_letters);
			printf("Word contains %c\n",guess);
		}
		else if(is_guess_valid(word,guessed_letters,guess)==-1){
			wrong_guesses++;
			printf("The word does not contain %c\n",guess); //the condition if guess is not in word
			display_word_status(word,guessed_letters);
		}
		else if(is_guess_valid(word,guessed_letters,guess)==0){
			wrong_guesses++;
			printf("You have %d\n guesses left.",max_guesses-wrong_guesses);
			display_word_status(word,guessed_letters);
		}
	}
	if(wrong_guesses=max_guesses){

		if(is_word_guessed(word,guessed_letters,guessed_count)==1){ //if word has been fully guessed.
			printf("Congratulations you guessed the word %s\n",word);
			return 1;
		}
		else if(is_word_guessed(word,guessed_letters,guessed_count)==0){ //if not fully guessed.
			printf("You ran out of guesses. Game over!");
			return 0;	
		}
		//break;
	}	
	
			



			
	

			
		
					

}


// Function to play the word guessing game
void play_game(char* file_name){
	int total_round=0;
	int win_round=0;
	int lose_round=0;
	char answer;
	char *word=get_random_word(file_name);
	
	//guess_word(word);
	int a=guess_word(word);
	if(a==1){
		win_round++;
		total_round++;
		printf("Do you want to play again?\n"); //takes input from user
		scanf("%c\n",&answer);
		if(answer=='Y'|| answer=='y'){ //if the input is 'y ' make it play again
			char *word= get_random_word(file_name);
			if(guess_word(word)==1){
				win_round++;
				total_round++;
			}
			
			else if(guess_word(word)==0){
				total_round++;
				lose_round++;
			}
		}
		else if(answer=='N'|| answer=='n'){
			printf("You played %d\n times and you win %d\n times",total_round,win_round);
		}
		
	}	
	else if (guess_word(word)==0){
		lose_round++;
		total_round++;
		printf("Do you want to play again?\n");
		scanf("%c\n",answer);
		while(isalpha(answer)){
			if(answer=='Y'|| answer=='y'){
				char *word= get_random_word(file_name);
				if(guess_word(word)==1){
					win_round++;
					total_round++;
				}
				
				else if(guess_word(word)==0){
					total_round++;
					lose_round++;
				}
			}
			else if(answer=='N'|| answer=='n'){
				printf("You played %d\n times and you win %d\n times",total_round,win_round);
			}
		}
	}
	

}	
			

	
	
	
	
	



